// constants/images.js

export const IMAGES = {
  PLACEHOLDER: require('../../assets/GoClimb_Logo.png'),
};
