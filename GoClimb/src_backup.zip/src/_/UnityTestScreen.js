// GoClimb/src/screens/UnityTestScreen.js
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { View, Text, ActivityIndicator, StyleSheet, Alert, BackHandler, TouchableOpacity } from 'react-native';
import { useNavigation, useFocusEffect, useRoute } from '@react-navigation/native';
import RNFS from 'react-native-fs';
import UnityViewerFinal from '../components/UnityViewerFinal';
import { findCragFolder } from '../utils/LocalModelChecker';
import { LOCAL_DIR } from '../constants/folder_path';
import { useTheme } from '../context/ThemeContext';

// Test data constants
const testModelData = {
  "model_id": "MODEL-000003",
  "name": "So Cool AR",
  "crag": {
    "crag_id": "CRAG-000004",
    "name": "Green Attack",
    "location_lat": 1.36238,
    "location_lon": 103.77434,
    "location_details": {
      "city": "Singapore",
      "country": "Singapore"
    },
    "description": "some detail",
    "images_urls": []
  },
  "user": {
    "user_id": "uFcHklPPBtaNztsYCGwiZt2wG2B3",
    "username": "TestUser002",
    "email": "testuser002@gmail.com",
    "status": true,
    "profile_picture": "profile_pic.png",
    "profile_picture_url": ""
  },
  "status": "active",
  "download_urls_json": {
    "folder": "crags/CRAG-000004/models/MODEL-000003/",
    "files": [
      {
        "name": "Image_0.001.png",
        "path": "crags/CRAG-000004/models/MODEL-000003/Image_0.001.png",
        "download_url": "https://storage.googleapis.com/goclimb-39075.firebasestorage.app/crags/CRAG-000004/models/MODEL-000003/Image_0.001.png?Expires=1762664449&GoogleAccessId=firebase-adminsdk-fbsvc%40goclimb-39075.iam.gserviceaccount.com&Signature=dkUEYiXEKYXTqk%2BRSNzv3mpueBHtJU7N3zDuHiujUctF%2B7l0xNhkjxD3ToNHbwFQt3%2BdE4bjNx4c8CAtumi8BARb9cgjRNeVYJWQB%2BQ%2BA4tWeFogGy0r%2BvF3%2FUqQQI9ux4%2B459Pxzx9RR%2FYy4CUwtvXmRm3HQMLZ8jn%2BrcjJlJigxY62alJLkXZcIdUt4zKAO9oJRTS1fsua%2FsnSOLT0hvQbgPeDM1ZnndnIV9wkXqYQdZjsCC4TucjopA72s%2FNkGA1wHoujsoAP9ov1ro5OXWLrJvqNvWm%2FoRhzbIFyr%2FL1gDaShU%2F06wMoLV9PAc2ypL79vTd7EwGq4yiKxNdR5g%3D%3D"
      },
      {
        "name": "Image_1.001.png",
        "path": "crags/CRAG-000004/models/MODEL-000003/Image_1.001.png",
        "download_url": "https://storage.googleapis.com/goclimb-39075.firebasestorage.app/crags/CRAG-000004/models/MODEL-000003/Image_1.001.png?Expires=1762664449&GoogleAccessId=firebase-adminsdk-fbsvc%40goclimb-39075.iam.gserviceaccount.com&Signature=feed%2Fn6%2BuwubN1gf4MIf5PTQtCcPke%2BOuZZjnBRVrldCbwqxqLDo0DoOmlFjs%2BspXh9JGXF5TjaHS1efpgwauUqf74mMH%2BZKp0fqhqBvqCJwLFke7PrOdVS4IU9hNQeruUlo%2FAfJjOLZSYlHFR5bt%2BjTlxpUqhOHuxKxil7SZSL%2FvLqQNfJCFbTDJgHIRGaQuW2f%2F2VuFm1UUh%2FrP%2F8y6J%2BXKlkNs9cKcOmj9WQ%2BKIo72ZHvkxNfWVW1NjRtyU2najUnikIU5tsN1EII8MlVgHTwy7Lc0oYLQ2ZjZIGt0EkxWvazlxKKtE9XDz0p8CHj64JNbkSoLYNIwutA%2FKhaXA%3D%3D"
      },
      {
        "name": "TestModel.fbx",
        "path": "crags/CRAG-000004/models/MODEL-000003/TestModel.fbx",
        "download_url": "https://storage.googleapis.com/goclimb-39075.firebasestorage.app/crags/CRAG-000004/models/MODEL-000003/TestModel.fbx?Expires=1762664449&GoogleAccessId=firebase-adminsdk-fbsvc%40goclimb-39075.iam.gserviceaccount.com&Signature=Wid2WX9W9t7UR9lSq2gZgqbn%2BW%2BCTjG6MkhIlSrU1Div2RGWmXsyp0AWfvmFO8OmzBnbJ%2B6HoJ2QjY8v63pAv5YOJJKC6KWhitdtBoJHgf0Fb4JMl1g6aof4btFDD1WDRmZPg4OLcGLd0JpZ%2Fb5IPXkRcYqrOi1w3gk4NkLfc%2BPIjo9B%2FbUjHGZlboIfJjXTS4DcVH91qdYiTDgNnI15AFDXN9wJbQQ6EGPCwaIp8Mcelkq4V0azgHeJ01kM%2FQIAPs7866vh4aPTwjStgVE9dyD8QVbhKdQyBDmyZCpKZbEcNqA0GUvaFaB3clUHn%2B33Z9qFH3IDQwiWGDICrdVwLA%3D%3D"
      },
      {
        "name": "test.glb",
        "path": "crags/CRAG-000004/models/MODEL-000003/test.glb",
        "download_url": "https://storage.googleapis.com/goclimb-39075.firebasestorage.app/crags/CRAG-000004/models/MODEL-000003/test.glb?Expires=1762664449&GoogleAccessId=firebase-adminsdk-fbsvc%40goclimb-39075.iam.gserviceaccount.com&Signature=fEf07Nd%2FtX%2BGTmBNBYz%2FRI2bgNUKAtvHoU5Sun9%2FlhTynhfdF%2B%2FdhC54J2DQ2%2FDDzt2UUgjT9Zovz1e38E1w0tnUyrevOm4pW7uyUnE8AsqcN0Qrbjh9t%2F5pT9LH41XK6B4%2FOSyY32GaOosZhfbCYJxzqBS8qT932xNQCsGo31bjG6doCR%2BZBKw25Bxw9soGrR6yzLgcLtzJTrrC%2BPRnvke1k0GKFqvrUOES0c3AgEKn4%2BOmYE7rO5hZq1HKEkiT8Z2RqCm5ouhJFqijrSKT10p5YSbBaQkfFuvh1RCN8cqsirK086a6B4rum5uU4Bp1Lbtx72PP2uVi5lka9uyOoQ%3D%3D"
      }
    ]
  }
};

const testModelRouteData = {
  "model_route_data_id": "ROUTE_DATA-000002",
  "route_data": {
    "points": [
      {
        "pos": { "x": 0.8231182, "y": 0.288940638, "z": 0.6524628 },
        "order": 1
      },
      {
        "pos": { "x": 0.797394335, "y": 0.427935064, "z": 0.598075569 },
        "order": 2
      },
      {
        "pos": { "x": 0.735768259, "y": 0.5453338, "z": 0.5114546 },
        "order": 3
      },
      {
        "pos": { "x": 0.8017668, "y": 0.4146244, "z": 0.412398517 },
        "order": 4
      }
    ],
    "route_name": "Test Route"
  },
  "status": "active"
};

const UnityTestScreen = React.memo(() => {
  const navigation = useNavigation();
  const route = useRoute();
  const { colors } = useTheme();
  
  // Get parameters from navigation
  const { modelPath: passedModelPath, modelData, cragData } = route.params || {};
  
  // State management
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modelPath, setModelPath] = useState(null);
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [unityReady, setUnityReady] = useState(false);
  
  // Refs
  const unityInstanceRef = useRef(null);
  const downloadAbortController = useRef(null);
  const isComponentMounted = useRef(true);

  // Constants
  const MODEL_ID = 'MODEL-000003';
  const CRAG_ID = 'CRAG-000004';
  const ROUTE_ID = 'ROUTE-000011';

  // Memoized Unity data
  const unityData = useMemo(() => {
    if (!modelPath) return null;

    return {
      path: modelPath,
      normalizationJson: {
        scale: 0.001,
        pos_offset: { x: 0.0, y: 0.0, z: 0.0 },
        rot_offset: { x: 90.0, y: 0.0, z: 0.0 },
      },
      routeJson: testModelRouteData.route_data ? [testModelRouteData.route_data] : [],
    };
  }, [modelPath]);

  // Optimized model checking and downloading
  const checkAndPrepareModel = useCallback(async () => {
    if (!isComponentMounted.current) return;

    try {
      // If model path is passed from ARCragList, use it directly
      if (passedModelPath) {
        console.log('[UnityTestScreen] Using passed model path:', passedModelPath);
        setModelPath(passedModelPath);
        setLoading(false);
        return;
      }

      // Otherwise, use the default model checking logic
      console.log('[UnityTestScreen] Checking for model:', MODEL_ID);
      
      const existingPath = await findCragFolder(MODEL_ID);
      
      if (existingPath) {
        const glbPath = `${existingPath}test.glb`;
        const glbExists = await RNFS.exists(glbPath);
        
        if (glbExists) {
          console.log('[UnityTestScreen] Model found at:', glbPath);
          if (isComponentMounted.current) {
            setModelPath(glbPath);
            setLoading(false);
          }
          return;
        }
      }
      
      console.log('[UnityTestScreen] Model not found, downloading...');
      await downloadModel();
    } catch (err) {
      console.error('[UnityTestScreen] Error checking model:', err);
      if (isComponentMounted.current) {
        setError(err.message);
        setLoading(false);
      }
    }
  }, []);

  // Optimized download with progress and cancellation
  const downloadModel = useCallback(async () => {
    if (!isComponentMounted.current) return;

    setDownloading(true);
    setDownloadProgress(0);

    try {
      const modelDir = `${LOCAL_DIR.BASE_DIR}/crags/${CRAG_ID}/models/${MODEL_ID}`;
      await RNFS.mkdir(modelDir, { recursive: true });

      const filesToDownload = testModelData.download_urls_json.files;
      const totalFiles = filesToDownload.length;

      // Create abort controller for cancellation
      downloadAbortController.current = new AbortController();

      for (let i = 0; i < filesToDownload.length; i++) {
        if (!isComponentMounted.current) break;

        const file = filesToDownload[i];
        const filePath = `${modelDir}/${file.name}`;
        
        console.log(`[UnityTestScreen] Downloading ${file.name} (${i + 1}/${totalFiles})`);
        
        const downloadResult = await RNFS.downloadFile({
          fromUrl: file.download_url,
          toFile: filePath,
          progress: (res) => {
            if (isComponentMounted.current) {
              const progress = ((i + res.bytesWritten / res.contentLength) / totalFiles) * 100;
              setDownloadProgress(Math.round(progress));
            }
          },
        }).promise;

        if (downloadResult.statusCode !== 200) {
          throw new Error(`Failed to download ${file.name}: Status ${downloadResult.statusCode}`);
        }
      }

      if (isComponentMounted.current) {
        const glbPath = `${modelDir}/test.glb`;
        setModelPath(glbPath);
        setDownloading(false);
        setLoading(false);
        console.log('[UnityTestScreen] Model download complete');
      }
    } catch (err) {
      console.error('[UnityTestScreen] Download error:', err);
      if (isComponentMounted.current) {
        setError(`Download failed: ${err.message}`);
        setDownloading(false);
        setLoading(false);
        
        Alert.alert(
          'Download Failed',
          `Failed to download model: ${err.message}`,
          [{ text: 'Retry', onPress: downloadModel }, { text: 'Cancel' }]
        );
      }
    }
  }, []);

  // Unity callbacks - optimized
  const handleUnityReady = useCallback(() => {
    console.log('[UnityTestScreen] ✓ Unity ready - scene loaded and data processed');
    setUnityReady(true);
    setError(null);
  }, []);

  const handleUnityFail = useCallback((errorMessage) => {
    console.error('[UnityTestScreen] ✗ Unity failed:', errorMessage);
    setUnityReady(false);
    setError(`Unity Error: ${errorMessage}`);
  }, []);

  const handleUnityMessage = useCallback((message) => {
    console.log('[UnityTestScreen] Unity message:', message);
    // Custom message handling can be added here
  }, []);

  // Unity ref callback
  const handleUnityRef = useCallback((ref) => {
    unityInstanceRef.current = ref;
  }, []);

  // Test message handlers
  const handleSendTestMessage = useCallback(() => {
    if (unityInstanceRef.current) {
      const testMessage = {
        action: 'test',
        message: 'Hello from React Native!',
        timestamp: Date.now()
      };
      
      console.log('[UnityTestScreen] Sending test message:', testMessage);
      unityInstanceRef.current.postMessage('UnityReceiver', 'TestMessage', JSON.stringify(testMessage));
      
      Alert.alert('Message Sent', 'Test message sent to Unity');
    } else {
      Alert.alert('Error', 'Unity reference not available');
    }
  }, []);

  const handleSendClearMessage = useCallback(() => {
    if (unityInstanceRef.current) {
      const clearMessage = {
        action: 'clear_scene',
        reason: 'manual_test',
        timestamp: Date.now()
      };
      
      console.log('[UnityTestScreen] Sending clear message:', clearMessage);
      unityInstanceRef.current.postMessage('UnityReceiver', 'ClearScene', JSON.stringify(clearMessage));
      
      Alert.alert('Message Sent', 'Clear scene message sent to Unity');
    } else {
      Alert.alert('Error', 'Unity reference not available');
    }
  }, []);

  const handleSendLoadMessage = useCallback(() => {
    if (unityInstanceRef.current && unityData) {
      console.log('[UnityTestScreen] Sending load message:', unityData);
      unityInstanceRef.current.postMessage('UnityReceiver', 'LoadIndoorScene', JSON.stringify(unityData));
      
      Alert.alert('Message Sent', 'Load scene message sent to Unity');
    } else {
      Alert.alert('Error', 'Unity reference or model data not available');
    }
  }, [unityData]);

  // Back button handler
  const handleBackPress = useCallback(() => {
    console.log('[UnityTestScreen] Back button pressed');
    
    // Cancel any ongoing downloads
    if (downloadAbortController.current) {
      downloadAbortController.current.abort();
    }
    
    // Navigate back
    navigation.goBack();
    return true;
  }, [navigation]);

  // Initialize model checking
  useEffect(() => {
    checkAndPrepareModel();
  }, [checkAndPrepareModel]);

  // Component mount/unmount tracking
  useEffect(() => {
    isComponentMounted.current = true;
    
    return () => {
      isComponentMounted.current = false;
      
      // Cancel any ongoing downloads
      if (downloadAbortController.current) {
        downloadAbortController.current.abort();
      }
    };
  }, []);

  // Back button handling
  useFocusEffect(
    useCallback(() => {
      const backHandler = BackHandler.addEventListener('hardwareBackPress', handleBackPress);
      return () => backHandler.remove();
    }, [handleBackPress])
  );

  // Loading state
  if (loading || downloading) {
    return (
      <View style={[styles.centerContainer, { backgroundColor: colors.bg }]}>
        <ActivityIndicator size="large" color={colors.accent} />
        <Text style={[styles.loadingText, { color: colors.text }]}>
          {downloading 
            ? `Downloading model... ${downloadProgress}%` 
            : 'Checking model...'
          }
        </Text>
        {downloading && (
          <View style={[styles.progressBar, { backgroundColor: colors.divider }]}>
            <View 
              style={[
                styles.progressFill, 
                { 
                  backgroundColor: colors.accent,
                  width: `${downloadProgress}%`
                }
              ]} 
            />
          </View>
        )}
      </View>
    );
  }

  // Error state
  if (error) {
    return (
      <View style={[styles.centerContainer, { backgroundColor: colors.bg }]}>
        <Text style={[styles.errorText, { color: colors.error || '#FF6B6B' }]}>
          Error: {error}
        </Text>
      </View>
    );
  }

  // Unity view
  if (!unityData) {
    return (
      <View style={[styles.centerContainer, { backgroundColor: colors.bg }]}>
        <Text style={[styles.errorText, { color: colors.error || '#FF6B6B' }]}>
          Model path not available
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <UnityViewerFinal
        modelData={unityData}
        showTestButton={true}
        navigation={navigation}
        modelId={MODEL_ID}
        routeId={ROUTE_ID}
        cragId={CRAG_ID}
        autoSaveRouteData={true}
        onUnityRef={handleUnityRef}
        onUnityReady={handleUnityReady}
        onUnityMessage={handleUnityMessage}
      />
      
      {/* AR Loading overlay - only show when Unity is not ready */}
      {!unityReady && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color="#FFFFFF" />
          <Text style={styles.loadingOverlayText}>Loading AR</Text>
        </View>
      )}

      {/* Test Message Buttons */}
      <View style={styles.testButtonsContainer}>
        <TouchableOpacity
          style={[styles.testButton, { backgroundColor: colors.accent }]}
          onPress={handleSendTestMessage}>
          <Text style={styles.testButtonText}>Send Test Message</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.testButton, { backgroundColor: '#FF6B6B' }]}
          onPress={handleSendClearMessage}>
          <Text style={styles.testButtonText}>Clear Scene</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.testButton, { backgroundColor: '#4CAF50' }]}
          onPress={handleSendLoadMessage}>
          <Text style={styles.testButtonText}>Load Scene</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    fontWeight: '500',
    textAlign: 'center',
  },
  errorText: {
    fontSize: 16,
    fontWeight: '500',
    textAlign: 'center',
  },
  progressBar: {
    width: '80%',
    height: 8,
    borderRadius: 4,
    marginTop: 16,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  loadingOverlayText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    textAlign: 'center',
  },
  testButtonsContainer: {
    position: 'absolute',
    bottom: 50,
    left: 20,
    right: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 10,
    zIndex: 1001,
  },
  testButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    elevation: 5,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  testButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

UnityTestScreen.displayName = 'UnityTestScreen';

export default UnityTestScreen;