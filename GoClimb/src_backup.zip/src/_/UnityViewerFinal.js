import React, { Component, forwardRef, useCallback } from 'react';
import { View, TouchableOpacity, Text, Alert } from 'react-native';
import UnityView from '@azesmway/react-native-unity';
import { useFocusEffect } from '@react-navigation/native';
import { RouteDataStorage } from '../services/storage/RouteDataStorage';

// Global Unity reference for cleanup
let globalUnityRef = null;

class UnityViewerFinal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isReady: false,
        };
        this.unityRef = null;
        this.messageQueue = [];
        this.hasLoadedScene = false;
        this.loadSceneTimer = null;
    }

    componentWillUnmount() {
        if (this.loadSceneTimer) {
            clearTimeout(this.loadSceneTimer);
        }
        globalUnityRef = null;
    }

    setUnityRef = (ref) => {
        this.unityRef = ref;
        globalUnityRef = ref; // Store globally for cleanup

        if (this.props.onUnityRef && ref) this.props.onUnityRef(ref);

        // Send message BEFORE Unity sends UNITY_READY (3 second delay)
        if (ref && this.props.modelData?.path && !this.hasLoadedScene) {
            this.loadSceneTimer = setTimeout(() => {
                this.loadScene();
            }, 3000);
        }
    };

    sendMessage = (gameObject, method, message) => {
        if (!this.unityRef) {
            this.messageQueue.push({ gameObject, method, message });
            return false;
        }
        try {
            const messageStr = typeof message === 'string' ? message : JSON.stringify(message);
            this.unityRef.postMessage(gameObject, method, messageStr);
            return true;
        } catch (error) {
            console.error('[UnityViewerFinal] Send failed:', error);
            return false;
        }
    };

    processQueue = () => {
        if (this.messageQueue.length === 0) return;
        this.messageQueue.forEach(({ gameObject, method, message }) => {
            this.sendMessage(gameObject, method, message);
        });
        this.messageQueue = [];
    };

    loadScene = () => {
        if (!this.props.modelData?.path) return;

        const sceneData = {
            path: this.props.modelData.path,
            normalizationJson: this.props.modelData.normalizationJson || {
                scale: 0.001, pos_offset: { x: 0, y: 0, z: 0 }, rot_offset: { x: 90, y: 0, z: 0 }
            },
            routeJson: this.props.modelData.routeJson || []
        };

        const success = this.sendMessage('UnityReceiver', 'LoadIndoorScene', sceneData);
        if (success) this.hasLoadedScene = true;
    };

    clearUnityScene = (reason) => {
        if (this.unityRef) {
            const clearData = { action: 'clear_scene', reason, timestamp: Date.now() };
            try {
                this.unityRef.postMessage('UnityReceiver', 'ClearScene', JSON.stringify(clearData));
                this.unityRef.postMessage('UnityReceiver', 'TestMessage', `cleanup_${reason}`);
                this.hasLoadedScene = false;
            } catch (error) {
                console.error('[UnityViewerFinal] Clear failed:', error);
            }
        }
    };

    handleMessage = async (result) => {
        const message = result.nativeEvent.message;
        try {
            if (message === 'UNITY_READY') {
                this.setState({ isReady: true });
                this.processQueue();
                if (this.props.onUnityReady) this.props.onUnityReady();
                return;
            }

            if (message.startsWith('UNITY_FAIL')) {
                Alert.alert('Unity Error', message.includes(':') ? message.split(':')[1] : 'Unknown error');
                return;
            }

            // Handle route data
            try {
                const routeData = JSON.parse(message);
                if (routeData.route_name && routeData.points && this.props.autoSaveRouteData) {
                    const displayName = routeData.display_name || routeData.custom_name || routeData.route_name;
                    const cleanRouteData = { route_name: routeData.route_name, points: routeData.points };
                    await RouteDataStorage.saveRouteData({
                        modelId: this.props.modelId, routeId: this.props.routeId, cragId: this.props.cragId,
                        routeData: cleanRouteData, customName: displayName
                    });
                    Alert.alert('Route Saved', `Route "${displayName}" saved locally`);
                }
            } catch (parseError) { }

            if (this.props.onUnityMessage) this.props.onUnityMessage(message);

        } catch (error) {
            console.error('[UnityViewerFinal] Message error:', error);
        }
    };

    handleTest = () => {
        const testData = {
            path: this.props.modelData?.path || '/test/path',
            normalizationJson: { scale: 0.001, pos_offset: { x: 0, y: 0, z: 0 }, rot_offset: { x: 90, y: 0, z: 0 } },
            routeJson: [{ route_name: 'Test Route', points: [{ order: 1, pos: { x: 0.1, y: 0.1, z: 0.1 } }] }]
        };
        this.sendMessage('UnityReceiver', 'LoadIndoorScene', testData);
    };

    render() {
        const { showTestButton = false, style } = this.props;
        const { isReady } = this.state;

        return (
            <View style={[{ flex: 1 }, style]}>
                <UnityView
                    ref={this.setUnityRef}
                    style={{ flex: 1 }}
                    onUnityMessage={this.handleMessage}
                />

                {showTestButton && (
                    <TouchableOpacity
                        style={{
                            position: 'absolute', top: 50, right: 20, padding: 12,
                            backgroundColor: isReady ? '#4CAF50' : '#007AFF',
                            borderRadius: 8, elevation: 5
                        }}
                        onPress={this.handleTest}>
                        <Text style={{ color: 'white', fontWeight: 'bold', fontSize: 12 }}>
                            {isReady ? 'Ready' : 'Test'}
                        </Text>
                    </TouchableOpacity>
                )}
            </View>
        );
    }
}

// Wrapper with focus cleanup
const UnityViewerWithCleanup = forwardRef((props, ref) => {
    // Handle screen unfocus - send clear message while Unity is still active
    useFocusEffect(
        useCallback(() => {
            return () => {
                console.log('[UnityViewerSimple] Screen unfocused - cleaning Unity');
                if (globalUnityRef) {
                    setTimeout(() => {
                        try {
                            const clearData = { action: 'clear_scene', reason: 'unfocus', timestamp: Date.now() };
                            globalUnityRef.postMessage('UnityReceiver', 'ClearScene', JSON.stringify(clearData));
                            console.log('[UnityViewerSimple] Cleanup message sent after short delay');
                        } catch (error) {
                            console.error('[UnityViewerSimple] Cleanup failed:', error);
                        }
                    }, 500); // half-second delay
                }
            };

        }, [])
    );

    return <UnityViewerFinal ref={ref} {...props} />;
});

export default UnityViewerWithCleanup;