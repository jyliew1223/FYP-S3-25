// GoClimb/src/services/api/PostsService.js

import { getAuth } from '@react-native-firebase/auth';
import {
  RequestMethod,
  CustomApiRequest,
} from './ApiHelper';
import { API_ENDPOINTS } from '../../constants/api';

/* ----------------------------- helpers ----------------------------- */
function toTs(value) {
  try {
    return value ? Date.parse(value) : Date.now();
  } catch {
    return Date.now();
  }
}

/* -------------------------- model mapping -------------------------- */

function getAuthorName(rawUser) {
  // backend may send user as UID string OR object { user_id, username, email }
  if (!rawUser) return 'User';
  if (typeof rawUser === 'string') return 'User';
  if (rawUser.username) return rawUser.username;
  if (rawUser.email) return rawUser.email;
  return 'User';
}

function mapPostJsonToUi(raw) {
  if (!raw) return null;

  console.log('[DEBUG mapPostJsonToUi raw]', raw);

  const postId = String(raw.post_id ?? '');
  const authorName = getAuthorName(raw.user);
  const createdTs = toTs(raw.created_at);

  // prefer serialized title; fallback to content snippet
  let uiTitle = '';
  if (typeof raw.title === 'string' && raw.title.trim()) {
    uiTitle = raw.title.trim();
  } else if (typeof raw.content === 'string' && raw.content.trim()) {
    const trimmed = raw.content.trim();
    uiTitle = trimmed.length > 70 ? trimmed.slice(0, 67).trim() + '…' : trimmed;
  } else {
    uiTitle = 'Untitled';
  }

  const likes = Number(raw.likes ?? raw.likes_count ?? raw.like_count ?? 0);
  const comments = Number(
    raw.comments ?? raw.comments_count ?? raw.comment_count ?? 0,
  );

  const imageUrl =
    Array.isArray(raw.images_urls) && raw.images_urls.length
      ? raw.images_urls[0]
      : null;

  const images = Array.isArray(raw.images_urls) ? raw.images_urls : [];

  return {
    id: postId,
    author: { id: String(raw.user?.user_id ?? ''), name: authorName },
    title: uiTitle,
    body: raw.content || '',
    tags: raw.tags || [],
    createdAt: createdTs,
    likes,
    comments, // fallback until we hydrate with fetchCommentCountForPost
    imageUrl, // Keep for backward compatibility
    images, // All images array
  };
}

function mapCommentJsonToUi(raw) {
  if (!raw) return null;

  console.log('[DEBUG mapCommentJsonToUi raw]', raw);

  const authorName = getAuthorName(raw.user);
  return {
    id: String(raw.comment_id ?? raw.id ?? ''),
    author: { id: String(raw.user?.user_id ?? ''), name: authorName },
    text: raw.content || '',
    createdAt: toTs(raw.created_at),
  };
}

/* ------------------------ payload/response ------------------------- */

// Removed GetRandomPostsPayload class - using plain object instead

// Removed GetRandomPostsResponse class - using direct JSON parsing instead

// Removed GetPostResponse class - using direct JSON parsing instead

// Removed GetCommentsResponse class - using direct JSON parsing instead

// Removed CreateCommentPayload class - using plain object instead

// Removed CreateCommentResponse class - using direct JSON parsing instead

/* -- CreatePost payload/response ----------------------------------- */

// Removed CreatePostPayload class - using plain object instead

// Removed CreatePostResponse class - using direct JSON parsing instead

/* --------------------------- service calls -------------------------- */

// FEED POSTS
export async function fetchRandomPosts({ count = 12, blacklist = [] } = {}) {
  const payload = {
    count,
    blacklist: Array.isArray(blacklist) ? blacklist : []
  };

  const request = new CustomApiRequest(
    RequestMethod.POST,
    API_ENDPOINTS.BASE_URL,
    API_ENDPOINTS.POST.GET_RANDOM_POSTS,
    payload,
    true,
  );

  await request.sendRequest();
  const response = request.JsonObject;

  if (!response?.success) {
    return {
      success: false,
      message: response?.message || 'Failed to load posts',
      errors: response?.errors || {},
      data: []
    };
  }

  // Map the posts to UI format
  const mappedPosts = Array.isArray(response.data) 
    ? response.data.map(mapPostJsonToUi).filter(Boolean)
    : [];

  console.log('[DEBUG fetchRandomPosts mapped]', mappedPosts);

  return {
    success: true,
    message: response.message || 'Posts loaded successfully',
    data: mappedPosts,
    errors: null
  };
}

// SINGLE POST
export async function fetchPostById(postId) {
  const payload = { post_id: postId };

  // Try POST first
  let req = new CustomApiRequest(
    RequestMethod.GET,
    API_ENDPOINTS.BASE_URL,
    API_ENDPOINTS.POST.GET_POST,
    payload,
    true,
  );
  await req.sendRequest();
  const response = req.JsonObject;

  console.log('[DEBUG fetchPostById mapped]', response?.data);

  if (!response?.success) {
    return {
      success: false,
      message: response?.message || 'Failed to fetch post',
      errors: response?.errors || {},
      data: null
    };
  }

  return {
    success: true,
    message: response.message || 'Post fetched successfully',
    data: response.data ? mapPostJsonToUi(response.data) : null,
    errors: null
  };
}

// COMMENTS LIST
export async function fetchCommentsByPostId(postId) {
  const payload = { post_id: postId };

  // Try POST first
  let req = new CustomApiRequest(
    RequestMethod.GET,
    API_ENDPOINTS.BASE_URL,
    API_ENDPOINTS.COMMENT.GET_COMMENTS_BY_POST_ID,
    payload,
    true,
  );
  await req.sendRequest();
  const response = req.JsonObject;

  if (!response?.success) {
    return {
      success: false,
      message: response?.message || 'Failed to fetch comments',
      errors: response?.errors || {},
      data: []
    };
  }

  return {
    success: true,
    message: response.message || 'Comments fetched successfully',
    data: Array.isArray(response.data) ? response.data.map(mapCommentJsonToUi).filter(Boolean) : [],
    errors: null,
  };
}

// comment count helper for Forum
export async function fetchCommentCountForPost(postId) {
  const res = await fetchCommentsByPostId(postId);
  if (res?.success) {
    return res.data.length;
  }
  return 0;
}

// CREATE COMMENT
export async function createComment({ postId, content }) {
  const user = getAuth().currentUser;
  if (!user) throw new Error('No Firebase session found.');

  const req = new CustomApiRequest(
    RequestMethod.POST,
    API_ENDPOINTS.BASE_URL,
    API_ENDPOINTS.COMMENT.CREATE_COMMENT,
    {
      post_id: postId,
      user_id: user.uid,
      content,
    },
    true,
  );
  await req.sendRequest();
  const response = req.JsonObject;

  if (!response?.success) {
    return {
      success: false,
      message: response?.message || 'Failed to create comment',
      errors: response?.errors || {},
      data: null
    };
  }

  return {
    success: true,
    message: response.message || 'Comment created successfully',
    data: response.data ? mapCommentJsonToUi(response.data) : null,
    errors: null,
  };
}

// DELETE COMMENT
export async function deleteComment(commentId) {
  console.log('[deleteComment] === START ===');
  console.log('[deleteComment] Input commentId:', commentId);
  console.log('[deleteComment] commentId type:', typeof commentId);

  const user = getAuth().currentUser;
  if (!user) {
    console.log('[deleteComment] ERROR: No Firebase session found');
    throw new Error('No Firebase session found.');
  }

  console.log('[deleteComment] Current user UID:', user.uid);

  const payload = { comment_id: commentId };

  console.log('[deleteComment] Payload:', JSON.stringify(payload));
  console.log('[deleteComment] Endpoint:', API_ENDPOINTS.COMMENT.DELETE_COMMENT);
  console.log('[deleteComment] Full URL:', API_ENDPOINTS.BASE_URL + '/' + API_ENDPOINTS.COMMENT.DELETE_COMMENT);

  const req = new CustomApiRequest(
    RequestMethod.DELETE,
    API_ENDPOINTS.BASE_URL,
    API_ENDPOINTS.COMMENT.DELETE_COMMENT,
    payload,
    true,
  );

  console.log('[deleteComment] Sending request...');
  await req.sendRequest();
  const response = req.JsonObject;

  console.log('[deleteComment] Response:', response);
  console.log('[deleteComment] === END ===');

  if (!response?.success) {
    return {
      success: false,
      message: response?.message || 'Failed to delete comment',
      errors: response?.errors || {},
      data: null
    };
  }

  return {
    success: true,
    message: response.message || 'Comment deleted successfully',
    data: response.data || null,
    errors: null
  };
}

// LIKE STATUS CHECK
export async function checkIfUserLikedPost(postId) {
  const user = getAuth().currentUser;
  if (!user) {
    console.log('[DEBUG checkIfUserLikedPost] No user logged in');
    return false;
  }

  const payload = { post_id: postId };

  const req = new CustomApiRequest(
    RequestMethod.GET,
    API_ENDPOINTS.BASE_URL,
    API_ENDPOINTS.POST_LIKE.LIKES_USERS,
    payload,
    true,
  );
  const ok = await req.sendRequest();
  const res = req.JsonObject;

  console.log('[DEBUG checkIfUserLikedPost]', {
    postId,
    ok,
    success: res?.success,
    users: res?.data?.users,
    currentUserId: user.uid,
  });

  if (ok && res?.success && res?.data?.users) {
    const userLiked = res.data.users.some(u => u.user_id === user.uid);
    console.log('[DEBUG checkIfUserLikedPost] userLiked:', userLiked);
    return userLiked;
  }

  console.log('[DEBUG checkIfUserLikedPost] Returning false (no match)');
  return false;
}

// GET LIKE COUNT
export async function getLikeCount(postId) {
  const payload = { post_id: postId };

  const req = new CustomApiRequest(
    RequestMethod.GET,
    API_ENDPOINTS.BASE_URL,
    API_ENDPOINTS.POST_LIKE.LIKES_COUNT,
    payload,
    true,
  );
  await req.sendRequest();
  const response = req.JsonObject;

  console.log('[DEBUG getLikeCount]', {
    postId,
    success: response?.success,
    response,
  });

  if (response?.success && response?.data) {
    // Get count from the raw JSON data
    const count = response.data.count ?? response.data.likes_count ?? response.data.like_count ?? 0;
    console.log('[DEBUG getLikeCount] Extracted count:', count);
    return { success: true, count };
  }

  return { success: false, count: 0 };
}

// LIKE / UNLIKE
export async function likePost(postId) {
  const user = getAuth().currentUser;

  if (!user) throw new Error('No Firebase session found.');

  const payload = { post_id: postId, user_id: user.uid };

  const request = new CustomApiRequest(
    RequestMethod.POST,
    API_ENDPOINTS.BASE_URL,
    API_ENDPOINTS.POST_LIKE.LIKE,
    payload,
    true,
  );

  await request.sendRequest();
  const response = request.JsonObject;

  if (!response?.success) {
    return {
      success: false,
      message: response?.message || 'Failed to like post',
      errors: response?.errors || {}
    };
  }

  return {
    success: true,
    message: response.message || 'Post liked successfully',
    errors: null
  };
}

export async function unlikePost(postId) {
  const user = getAuth().currentUser;
  if (!user) throw new Error('No Firebase session found.');

  const payload = { post_id: postId, user_id: user.uid };

  const request = new CustomApiRequest(
    RequestMethod.POST,
    API_ENDPOINTS.BASE_URL,
    API_ENDPOINTS.POST_LIKE.UNLIKE,
    payload,
    true,
  );

  await request.sendRequest();
  const response = request.JsonObject;

  if (!response?.success) {
    return {
      success: false,
      message: response?.message || 'Failed to unlike post',
      errors: response?.errors || {}
    };
  }

  return {
    success: true,
    message: response.message || 'Post unliked successfully',
    errors: null
  };
}

// CREATE POST
export async function createPost({ title, content, tags, images = [] }) {
  const user = getAuth().currentUser;
  if (!user) throw new Error('No Firebase session found.');

  let payload;

  // If images are provided, use FormData for multipart upload
  if (images && images.length > 0) {
    const formData = new FormData();
    formData.append('user_id', user.uid);
    formData.append('title', title);
    formData.append('content', content);
    
    // Append tags as JSON string or individual items
    formData.append('tags', JSON.stringify(tags));

    // Append each image
    images.forEach((image, index) => {
      const fileUri = image.fileCopyUri || image.uri;
      const fileName = image.name || `image_${index}.jpg`;
      const fileType = image.type || 'image/jpeg';

      formData.append('images', {
        uri: fileUri,
        type: fileType,
        name: fileName,
      });
    });

    payload = formData;
  } else {
    // No images, use regular JSON payload
    payload = {
      user_id: user.uid,
      title,
      content,
      tags,
    };
  }

  const request = new CustomApiRequest(
    RequestMethod.POST,
    API_ENDPOINTS.BASE_URL,
    API_ENDPOINTS.POST.CREATE_POST,
    payload,
    true,
  );

  await request.sendRequest();
  const response = request.JsonObject;

  console.log('[DEBUG createPost response]', response);

  if (!response?.success) {
    return {
      success: false,
      message: response?.message || 'Failed to create post',
      errors: response?.errors || {},
      data: null
    };
  }

  return {
    success: true,
    message: response.message || 'Post created successfully',
    data: mapPostJsonToUi(response.data),
    errors: null
  };
}

// DELETE POST
export async function deletePost(postId) {
  console.log('[deletePost] === START ===');
  console.log('[deletePost] Input postId:', postId);
  
  const user = getAuth().currentUser;
  if (!user) {
    console.log('[deletePost] ERROR: No Firebase session found');
    throw new Error('No Firebase session found.');
  }

  console.log('[deletePost] Current user UID:', user.uid);

  const payload = { post_id: postId };

  console.log('[deletePost] Payload:', JSON.stringify(payload));
  console.log('[deletePost] Endpoint:', API_ENDPOINTS.POST.DELETE_POST);

  const req = new CustomApiRequest(
    RequestMethod.DELETE,
    API_ENDPOINTS.BASE_URL,
    API_ENDPOINTS.POST.DELETE_POST,
    payload,
    true,
  );
  
  console.log('[deletePost] Sending request...');
  await req.sendRequest();
  const response = req.JsonObject;

  console.log('[deletePost] Response:', response);
  console.log('[deletePost] === END ===');

  if (!response?.success) {
    return {
      success: false,
      message: response?.message || 'Failed to delete post',
      errors: response?.errors || {}
    };
  }

  return {
    success: true,
    message: response.message || 'Post deleted successfully',
    errors: null
  };
}
