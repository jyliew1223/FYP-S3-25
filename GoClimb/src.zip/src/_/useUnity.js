// GoClimb/src/hooks/useUnity.js - Optimized Unity Hook
import { useRef, useCallback, useEffect, useState } from 'react';

/**
 * Optimized Unity hook for managing Unity state and communication
 */
export const useUnity = (options = {}) => {
    const {
        autoLoad = true,
        maxRetries = 3,
        startupDelay = 2000,
        onReady,
        onFail,
        onMessage
    } = options;

    // State
    const [isReady, setIsReady] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    // Refs
    const unityRef = useRef(null);
    const messageQueue = useRef([]);
    const retryCount = useRef(0);
    const isComponentMounted = useRef(true);

    // Send message with queue support
    const sendMessage = useCallback((gameObject, method, message) => {
        if (!unityRef.current) {
            console.warn('[useUnity] Queueing message - Unity not ready');
            messageQueue.current.push({ gameObject, method, message });
            return false;
        }

        try {
            const messageStr = typeof message === 'string' ? message : JSON.stringify(message);
            unityRef.current.postMessage(gameObject, method, messageStr);
            console.log(`[useUnity] ✓ Sent: ${gameObject}.${method}`);
            return true;
        } catch (err) {
            console.error('[useUnity] ✗ Send failed:', err);
            return false;
        }
    }, []);

    // Process message queue
    const processQueue = useCallback(() => {
        if (messageQueue.current.length === 0 || !isReady) return;

        console.log(`[useUnity] Processing ${messageQueue.current.length} queued messages`);
        
        const queue = [...messageQueue.current];
        messageQueue.current = [];

        queue.forEach(({ gameObject, method, message }) => {
            sendMessage(gameObject, method, message);
        });
    }, [isReady, sendMessage]);

    // Load scene
    const loadScene = useCallback((sceneData) => {
        if (!isComponentMounted.current) return;

        if (retryCount.current >= maxRetries) {
            const errorMsg = 'Max retry attempts exceeded';
            setError(errorMsg);
            if (onFail) onFail(errorMsg);
            return;
        }

        setIsLoading(true);
        setError(null);
        retryCount.current++;

        console.log(`[useUnity] Loading scene (attempt ${retryCount.current})`);
        sendMessage('UnityReceiver', 'LoadIndoorScene', sceneData);
    }, [sendMessage, maxRetries, onFail]);

    // Clear scene
    const clearScene = useCallback((reason = 'manual') => {
        console.log(`[useUnity] Clearing scene: ${reason}`);
        
        const clearData = {
            action: 'clear_scene',
            reason,
            timestamp: Date.now()
        };

        sendMessage('UnityReceiver', 'ClearScene', clearData);
        setIsReady(false);
        setIsLoading(false);
        setError(null);
    }, [sendMessage]);

    // Handle Unity ready
    const handleReady = useCallback(() => {
        if (!isComponentMounted.current) return;

        console.log('[useUnity] ✓ Unity ready');
        setIsReady(true);
        setIsLoading(false);
        setError(null);
        retryCount.current = 0;

        if (onReady) onReady();
        processQueue();
    }, [onReady, processQueue]);

    // Handle Unity failure
    const handleFail = useCallback((errorMessage) => {
        if (!isComponentMounted.current) return;

        console.error('[useUnity] ✗ Unity failed:', errorMessage);
        setIsReady(false);
        setIsLoading(false);
        setError(errorMessage);

        if (onFail) onFail(errorMessage);
    }, [onFail]);

    // Handle Unity messages
    const handleMessage = useCallback((message) => {
        try {
            if (message === 'UNITY_READY') {
                handleReady();
                return;
            }

            if (message === 'UNITY_FAIL' || message.startsWith('UNITY_FAIL:')) {
                const error = message.includes(':') ? message.split(':')[1] : 'Unknown error';
                handleFail(error);
                return;
            }

            if (onMessage) {
                onMessage(message);
            }
        } catch (err) {
            console.error('[useUnity] Message handling error:', err);
        }
    }, [handleReady, handleFail, onMessage]);

    // Set Unity ref
    const setUnityRef = useCallback((ref) => {
        unityRef.current = ref;
        console.log('[useUnity] Unity ref set:', !!ref);
    }, []);

    // Auto-load scene when data is available
    const autoLoadScene = useCallback((sceneData) => {
        if (!autoLoad || !sceneData || !unityRef.current) return;

        console.log('[useUnity] Auto-loading scene in', startupDelay, 'ms');
        
        setTimeout(() => {
            if (isComponentMounted.current) {
                loadScene(sceneData);
            }
        }, startupDelay);
    }, [autoLoad, startupDelay, loadScene]);

    // Retry loading
    const retry = useCallback(() => {
        retryCount.current = 0;
        setError(null);
        processQueue();
    }, [processQueue]);

    // Component lifecycle
    useEffect(() => {
        isComponentMounted.current = true;
        
        return () => {
            isComponentMounted.current = false;
            clearScene('component_unmount');
        };
    }, [clearScene]);

    return {
        // State
        isReady,
        isLoading,
        error,
        
        // Methods
        sendMessage,
        loadScene,
        clearScene,
        autoLoadScene,
        setUnityRef,
        handleMessage,
        retry,
        
        // Utils
        clearError: () => setError(null),
        getQueueLength: () => messageQueue.current.length
    };
};

export default useUnity;