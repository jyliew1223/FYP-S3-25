// constants/folder_path.js

import RNFS from 'react-native-fs';

export const LOCAL_DIR = {
  BASE_DIR: `${RNFS.ExternalDirectoryPath}/GoClimb`,
};
