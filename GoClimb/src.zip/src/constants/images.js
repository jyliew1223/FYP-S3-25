// constants/images.js

<<<<<<< Updated upstream
export const IMAGES = {
=======
export const DEFAULT_IMAGES = {
>>>>>>> Stashed changes
  PLACEHOLDER: require('../../assets/GoClimb_Logo.png'),
};
